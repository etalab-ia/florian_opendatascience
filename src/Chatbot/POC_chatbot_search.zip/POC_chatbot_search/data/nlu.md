## intent:greet
- Bonjour
- Hello 
- Salut 
- Salut à toi 
- Bienvenue

## intent:bye
- Au revoir 
- Adieu 
- A plus ! 
- A bientôt !
- bye 

## intent:thank
- Merci beaucoup
- Merci
- Encore merci
- Super! merci beaucoup

## intent: chercher_jdd
- Je cherche un dataset
- Je recherche un jeu de donnée 
- Je ne trouve pas l'information que je recherche
- Puis-je entrer ma recherche ? 
- est-ce que tu sais répondre ? 
- Peut-tu m'aider dans ma recherche ?


## intent:inform
- [recherche](recherche)
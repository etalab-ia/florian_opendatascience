## greet
* greet
  - utter_greet
  
## poser_une_question à Piaf
* chercher_jdd
  - form_recherche
  - form{"name": "form_recherche"}
  - form{"name": null}

## goodbye
* bye
  - utter_bye

## the user is OK with the answer
* user_satisfied
  - utter_happy_bot

## the user is nok with the answer
* user_not_satisfied
  - utter_bad_answer
  

    
